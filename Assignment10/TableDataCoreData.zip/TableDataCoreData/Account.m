//
//  Account.m
//  TableDataCoreData
//
//  Created by Quang Dai on 5/7/16.
//  Copyright © 2016 Quang Dai. All rights reserved.
//

#import "Account.h"

@implementation Account

// Insert code here to add functionality to your managed object subclass

@end
